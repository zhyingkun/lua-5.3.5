#define PA_GIT_REVISION unknown
